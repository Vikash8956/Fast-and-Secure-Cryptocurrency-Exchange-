export const GlobalReachData = [
    {
        id: 1,
        count: 6,
        postfix:"M+",
        title: "Active users"
    },
    {
        id: 2,
        count: 247,
        title: "Users support"
    },
    {
        id: 3,
        count: 160,
        postfix:"+",
        title: "Countries"
    },
    {
        id: 4,
        count: 22,
        prefix: "$",
        postfix:"B+",
        title: "Trade volume"
    },
]
