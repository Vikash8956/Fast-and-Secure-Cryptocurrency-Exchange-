export const brandList = [
    {
        image: "/images/brand/brand-logo-1.svg",
        title: "Adobe"
    },
    {
        image: "/images/brand/brand-logo-2.svg",
        title: "Figma"
    },
    {
        image: "/images/brand/brand-logo-3.svg",
        title: "Shopify"
    },
    {
        image: "/images/brand/brand-logo-4.svg",
        title: "Dribble"
    },
    {
        image: "/images/brand/brand-logo-5.svg",
        title: "Webflow"
    }
];